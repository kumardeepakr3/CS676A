import numpy as np
import cv2
import sys
import math


def generate_5d(image):
	(row,column,x)=image.shape
	final_matrix = np.zeros(shape=(row*column,5))
	iterator=0
	for i in xrange(0,row):
		for j in xrange(0,column):
			final_matrix[iterator]=[i,j,image[i][j][0],image[i][j][1],image[i][j][2]]
			iterator = iterator + 1
	print iterator
	return (final_matrix,row,column)

def gaussian(bandwidth_loc,bandwidth_col,distance_loc,distance_col):
	val = 1/(bandwidth_col*bandwidth_loc*2*math.pi)*np.exp(-0.5 *( ( distance_loc/(bandwidth_loc**2)+distance_col/(bandwidth_col**2))  ))
	# if val>1:
	# 	print bandwidth_loc,bandwidth_col,distance_loc,distance_col,val
	# # print val
	return val

def distance(array1,array2):
	array = array1 - array2
	distance_col=array[2]**2 + array[3]**2 + array[4]**2
	# print array[2],array[3],array[4]
	distance_loc = array[0]**2 + array[1]**2
	return (distance_loc,distance_col)


def KDE(image_5d,bandwidth_col,bandwidth_loc,row,column):
	size = row*column
	kde = np.zeros(shape=(row,column))
	for i in xrange(0,size):
		for x in xrange(0,size):
			(distance_loc,distance_col)=distance(image_5d[row],image_5d[x])
			kde[image_5d[row][0]][image_5d[row][1]] += gaussian(bandwidth_loc,bandwidth_col,distance_loc,distance_col) 
		# print i
	return kde

	
def shift_pixel(image,kde,window_size):
	for x in xrange(1,10):
		pass






if __name__ == "__main__":
	file_name = sys.argv[1]
	bandwidth_col = 1
	bandwidth_loc = 1
	row = 256
	column =256
	image = cv2.imread(file_name)
	# image = np.zeros(shape=(25,25,3))
	# image[15][15][0]=255
	# image[15][15][1]=255
	# image[15][15][2]=255
	# image = cv2.imread('42049.jpg',1)
	# cv2.imwrite('mess.jpg',image)
	# cv2.imshow('abc.jpg',image)
	# cv2.waitKey(0)

	(image_5d,row,column)=generate_5d(image)
	print image_5d
	kde=KDE(image_5d,bandwidth_col,bandwidth_loc,row,column)
	# print kde

	# shift_pixel(image,kde,window_size)
	