To Run:

1. Train using vocabtree.py
2. Set the values of k and height and the path to clusterdump and imagesPath
3. Then run classify.py with the same values set as above
